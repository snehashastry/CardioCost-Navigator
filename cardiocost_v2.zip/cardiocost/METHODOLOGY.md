# CardioCost Navigator - Methodology, Evidence and Limitations

*Decision-support prototype. Not a medical device, not a diagnosis, not clinically validated.*

## 1. Problem
Health plans and community programmes have limited outreach capacity. CardioCost Navigator helps them (a) screen for elevated
cardiovascular-disease risk using routine vitals, (b) understand *why* the model flags someone, and (c) compare outreach
allocation strategies - transparently, with uncertainty and fairness checks.

## 2. Data
`data/HeartFailureDataset.csv` - 70,000 public records (age, sex, height, weight, BP, cholesterol, glucose, smoking, alcohol, activity).
Target `cardio` = cardiovascular disease **present** in the record (a cross-sectional label, not a future event).
Audit (see `models/cardiac_metrics.json -> data_audit`): 24 exact duplicates dropped *before* splitting; no missing cells;
~1.57k further rows removed as physiologically implausible (BP out of range or systolic <= diastolic, BMI out of 12-60); 68,408 rows remain; classes balanced (~49.5% positive).
Encodings fixed: gender 1=female/2=male -> 0/1; age days -> years.

## 3. Cardiac model (`train_cardiac.py`)
* Split: 60/20/20 train/validation/test, stratified, seed 42. **Test set evaluated once**, after selection.
* Candidates (all sklearn Pipelines, preprocessing fit inside CV): Logistic Regression, Random Forest, Extra Trees,
  Hist Gradient Boosting; small grids, 5-fold stratified CV on train (ROC-AUC).
* Selection by validation ROC-AUC; threshold chosen on validation (maximise F1) = 0.39. Final model refit on train+validation.
* Metrics: accuracy, precision, recall, specificity, F1, ROC-AUC, PR-AUC, Brier, confusion matrix, calibration curve, subgroup table.
* XGBoost/LightGBM/SHAP were not used because the build environment had no network access; Hist Gradient Boosting is the
  sklearn equivalent, and Shapley values are computed by our own permutation estimator (`engine.shapley`).

### Result (held-out test, n = 13,682) - see dashboard "Model evidence" for live numbers
| Protocol | Accuracy | ROC-AUC | F1 | Brier |
|---|---|---|---|---|
| Original baseline (80/20, thr 0.5, no CV) | 0.7417 | 0.8045 | 0.7267 | 0.1790 |
| Rebuilt pipeline, thr 0.5 | 0.7406 | 0.8052 | 0.7252 | 0.1788 |
| Rebuilt pipeline, validation-chosen thr 0.39 | 0.7252 | 0.8052 | 0.7408 | 0.1788 |
**Honest reading:** discrimination did not meaningfully improve; all four model families land at CV AUC 0.79-0.80, which looks like
the ceiling of these 11 features. The 0.39 threshold trades accuracy for recall (0.79) - appropriate for screening outreach, but
it lowers specificity (0.66). What improved is trustworthiness: no leakage, CV, calibration (observed vs predicted within ~3 pts
in every decile bin on the test set), subgroup reporting, uncertainty and drift checks.

## 4. Insurance-cost model - audit outcome (`audit_insurance.py`)
The legacy Random Forest cannot be validated: its training data, target and unit are not in the repository, and 95% of its
importance is the input `annual_medical_cost`. Predictions saturate (~4.9k) and barely respond to clinical inputs. It is therefore
shown only as an *experimental, unreliable* field and is **never** used for segmentation or prioritisation. Segments use the
member's **observed prior-year cost**. Reporting MAE/RMSE/R2 would require the original data.

## 5. Innovation layer and its limits
| Technique | What it gives | Limits |
|---|---|---|
| Permutation-Shapley explanations (own implementation, probability scale, additive) | Per-patient "why" | Monte-Carlo noise; credit shared among correlated height/weight/BMI; explains the model, not causation |
| Uncertainty / OOD | Range checks, Mahalanobis distance, two-model disagreement, near-threshold flag | Heuristics; not calibrated confidence intervals |
| Model-based what-if | Shows how score moves if inputs change | Associational; **not** a treatment effect |
| Risk x observed-cost segmentation | Transparent four-way triage | Cost split is a configurable policy value (demo: median of synthetic cohort) |
| Outreach simulator | Compare strategies under limited capacity | "Cases averted" = modelled risk x **assumed** effect; hypothetical, no savings claimed |
| Fairness breakdown | Cohort vs selected share by sex/age; subgroup AUC/recall/specificity | Only sex/age/BMI available; no ethnicity/income; parity != fairness |
| Drift monitor (PSI) | Flags cohort inputs that differ from training | Input drift only; cannot see label drift |

## 6. Key limitations
* Label is existing disease in a public dataset of unknown provenance; risk is a screening score, not a probability of a future event.
* Single dataset, no external validation; performance in other populations (including India) is unknown.
* Ages mostly 30-65; BP self-reported or measured inconsistently in source data.
* Smoking/alcohol show almost no signal in this dataset - a data artefact, not medical guidance.
* Demo cohort is synthetic: real vitals, simulated insurance fields.

## 7. Privacy & security
Inputs processed in memory only; scored cohort cached in memory (16 most recent, random tokens), never written to disk or logged.
Strict range validation, 5 MB / 20k-row limits, CSV formula-injection neutralised, CSP and no-store headers, non-root container.
