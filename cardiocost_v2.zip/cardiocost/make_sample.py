"""Create a SYNTHETIC member cohort for demos (real cardiac vitals + simulated insurance fields),
and calibrate the cost split used by the risk x cost segmentation."""
import json
import numpy as np, pandas as pd
from train_cardiac import load_clean

rng = np.random.default_rng(7)
df = load_clean().sample(1500, random_state=7).reset_index(drop=True)
n = len(df)
age = df["age"].round().clip(18, 90)
chronic = (df["ap_hi"] >= 140).astype(int)
sample = pd.DataFrame(dict(
    member_id=[f"M{1000+i}" for i in range(n)], age=age, sex=df["gender"], height=df["height"], weight=df["weight"],
    systolic_bp=df["ap_hi"], diastolic_bp=df["ap_lo"], cholesterol=df["cholesterol"], gluc=df["gluc"],
    smoker=df["smoke"], alcohol=df["alco"], active=df["active"],
    income=(rng.lognormal(10.8, .5, n)).round(-2), household_size=rng.integers(1, 6, n),
    dependents=rng.integers(0, 4, n), hospitalizations_last_3yrs=rng.poisson(.4 + chronic * .4, n),
    medication_count=rng.poisson(1 + chronic * 2, n),
    hypertension=chronic, diabetes=(df["gluc"] > 1).astype(int), cardiovascular_disease=0,
))
sample["days_hospitalized_last_3yrs"] = sample["hospitalizations_last_3yrs"] * rng.integers(1, 6, n)
sample["annual_medical_cost"] = (800 + (age - 18) * 55 + sample["medication_count"] * 450
                                 + sample["hospitalizations_last_3yrs"] * 2200 + rng.gamma(2, 600, n)).round(2)
sample.to_csv("sample/sample_members_SYNTHETIC.csv", index=False)

# Segmentation uses OBSERVED prior-year cost, so the (unvalidated) insurance RF is not involved.
json.dump({"cost_split": float(sample["annual_medical_cost"].median()),
           "note": "median observed annual_medical_cost of the SYNTHETIC demo cohort; replace with your own cohort/policy threshold"},
          open("models/segment_config.json", "w"))
print("cost split", sample["annual_medical_cost"].median())
