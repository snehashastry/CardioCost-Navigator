"""Leakage-safe training + evaluation of the cardiac-risk model.

Protocol (all seeded, reproducible):
  1. Clean data (documented rules), drop exact duplicates BEFORE splitting.
  2. Split: 60% train / 20% validation / 20% test (stratified). Test is touched once, at the end.
  3. Every candidate is a Pipeline (preprocessing is fit inside CV folds -> no leakage).
  4. Model selection: 5-fold stratified CV on TRAIN only (ROC-AUC), small justified grids.
  5. Decision threshold chosen on VALIDATION (maximise F1 by default; also reports Youden-J).
  6. Chosen model refit on train+val, probabilities calibrated check on test; metrics saved.

Run:  python train_cardiac.py
"""
from __future__ import annotations
import json, time, warnings
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import (ExtraTreesClassifier, HistGradientBoostingClassifier,
                              RandomForestClassifier)
from sklearn.calibration import calibration_curve
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, average_precision_score, brier_score_loss,
                             confusion_matrix, f1_score, precision_recall_curve,
                             precision_score, recall_score, roc_auc_score, roc_curve)
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")
ROOT = Path(__file__).resolve().parent
SEED = 42
FEATURES = ["age", "gender", "height", "weight", "ap_hi", "ap_lo",
            "cholesterol", "gluc", "smoke", "alco", "active", "bmi"]


def load_raw() -> pd.DataFrame:
    return pd.read_csv(ROOT / "data" / "HeartFailureDataset.csv")


def audit(raw: pd.DataFrame) -> dict:
    feat_raw = [c for c in raw.columns if c != "id"]
    return dict(
        rows_raw=int(len(raw)), missing_cells=int(raw.isna().sum().sum()),
        exact_duplicates=int(raw.duplicated(subset=feat_raw).sum()),
        implausible_bp=int((~raw["ap_hi"].between(80, 200) | ~raw["ap_lo"].between(60, 140)).sum()),
        systolic_le_diastolic=int((raw["ap_hi"] <= raw["ap_lo"]).sum()),
        target="cardio (1 = cardiovascular disease present; dataset label, not a future-event outcome)",
        encodings="gender 1=female 2=male; cholesterol/gluc 1=normal 2=above 3=well above; age in days",
        class_balance=float(raw["cardio"].mean()),
    )


def load_clean(drop_duplicates: bool = True) -> pd.DataFrame:
    df = load_raw().drop(columns=["id"])
    if drop_duplicates:
        df = df.drop_duplicates()
    df["age"] = df["age"] / 365.25
    df = df[df["ap_hi"].between(80, 200) & df["ap_lo"].between(60, 140) & (df["ap_hi"] > df["ap_lo"])].copy()
    df["bmi"] = (df["weight"] / (df["height"] / 100) ** 2).round(2)
    df = df[df["bmi"].between(12, 60)]
    df["gender"] = (df["gender"] == 2).astype(int)  # 0 = female, 1 = male
    return df.reset_index(drop=True)


def candidates():
    cv = StratifiedKFold(5, shuffle=True, random_state=SEED)
    def gs(est, grid):
        return GridSearchCV(est, grid, cv=cv, scoring="roc_auc", n_jobs=1, refit=True)
    return {
        "Logistic Regression": gs(make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000)),
                                  {"logisticregression__C": [0.1, 1.0, 10.0]}),
        "Random Forest": gs(RandomForestClassifier(n_estimators=200, n_jobs=-1, random_state=SEED),
                            {"min_samples_leaf": [20, 50], "max_features": ["sqrt"]}),
        "Extra Trees": gs(ExtraTreesClassifier(n_estimators=200, n_jobs=-1, random_state=SEED),
                          {"min_samples_leaf": [20, 50]}),
        "Hist Gradient Boosting": gs(HistGradientBoostingClassifier(random_state=SEED, early_stopping=True),
                                     {"max_depth": [3, 4], "learning_rate": [0.05, 0.1],
                                      "l2_regularization": [1.0], "max_iter": [300]}),
    }


def metrics_at(y, p, thr):
    pred = (p >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred).ravel()
    return dict(accuracy=accuracy_score(y, pred), precision=precision_score(y, pred),
                recall=recall_score(y, pred), specificity=tn / (tn + fp), f1=f1_score(y, pred),
                roc_auc=roc_auc_score(y, p), pr_auc=average_precision_score(y, p),
                brier=brier_score_loss(y, p), confusion=[[int(tn), int(fp)], [int(fn), int(tp)]],
                threshold=float(thr))


def best_threshold(y, p, how="f1"):
    ts = np.linspace(0.2, 0.8, 121)
    if how == "youden":
        sc = [recall_score(y, p >= t) + confusion_matrix(y, p >= t)[0, 0] / (y == 0).sum() - 1 for t in ts]
    else:
        sc = [f1_score(y, p >= t) for t in ts]
    return float(ts[int(np.argmax(sc))])


def downsample_curve(x, y, n=80):
    idx = np.unique(np.linspace(0, len(x) - 1, n).astype(int))
    return np.asarray(x)[idx].round(5).tolist(), np.asarray(y)[idx].round(5).tolist()


def main():
    t0 = time.time()
    raw = load_raw()
    audit_info = audit(raw)
    df = load_clean()
    X, y = df[FEATURES], df["cardio"]
    Xtv, Xte, ytv, yte = train_test_split(X, y, test_size=0.2, random_state=SEED, stratify=y)
    Xtr, Xva, ytr, yva = train_test_split(Xtv, ytv, test_size=0.25, random_state=SEED, stratify=ytv)
    print(f"rows clean={len(df)}  train={len(Xtr)} val={len(Xva)} test={len(Xte)}")

    cvres, fitted, val_p = {}, {}, {}
    for name, gs in candidates().items():
        gs.fit(Xtr, ytr)
        fitted[name] = gs.best_estimator_
        pv = gs.best_estimator_.predict_proba(Xva)[:, 1]
        val_p[name] = pv
        cvres[name] = dict(cv_roc_auc_mean=float(gs.best_score_),
                           cv_roc_auc_std=float(gs.cv_results_["std_test_score"][gs.best_index_]),
                           best_params={k: (v if not isinstance(v, np.generic) else v.item())
                                        for k, v in gs.best_params_.items()},
                           val_roc_auc=float(roc_auc_score(yva, pv)), val_brier=float(brier_score_loss(yva, pv)))
        print(name, cvres[name])

    # Selection on CV + validation only (test untouched). Tie-break toward simpler/better-calibrated.
    best = max(cvres, key=lambda k: cvres[k]["val_roc_auc"])
    thr = best_threshold(yva, val_p[best], "f1")
    thr_youden = best_threshold(yva, val_p[best], "youden")
    print("selected:", best, "threshold(F1 on val)=", thr)

    # Refit chosen config on train+val; threshold stays as chosen on validation.
    from sklearn.base import clone
    final = clone(fitted[best]).fit(Xtv, ytv)

    # ---- single, final test evaluation (all candidates for the comparison table, same protocol) ----
    test_tbl, curves = {}, {}
    for name, est in fitted.items():
        e = final if name == best else est  # others stay train-only (honest comparison table)
        p = e.predict_proba(Xte)[:, 1]
        thr_n = thr if name == best else best_threshold(yva, val_p[name], "f1")
        test_tbl[name] = metrics_at(yte, p, thr_n)
        fpr, tpr, _ = roc_curve(yte, p); pr, rc, _ = precision_recall_curve(yte, p)
        fx, fy = downsample_curve(fpr, tpr); px, py = downsample_curve(rc, pr)
        curves[name] = dict(roc=dict(fpr=fx, tpr=fy), pr=dict(recall=px, precision=py))
    pt = final.predict_proba(Xte)[:, 1]
    fr, mp = calibration_curve(yte, pt, n_bins=10, strategy="quantile")

    # naive baseline for reference + the ORIGINAL baseline protocol (80/20, 0.5 thr, no val) reproduced
    # reference: same final model at the conventional 0.5 threshold (comparable to the original baseline)
    at_half = metrics_at(yte, pt, 0.5)

    # ---- subgroup analysis (test set) ----
    sub = {}
    groups = {"sex": Xte["gender"].map({0: "Female", 1: "Male"}),
              "age band": pd.cut(Xte["age"], [0, 45, 55, 65, 100], labels=["<45", "45-54", "55-64", "65+"]),
              "BMI band": pd.cut(Xte["bmi"], [0, 25, 30, 100], labels=["<25", "25-29.9", "30+"])}
    for gname, g in groups.items():
        rows = []
        for lvl in g.cat.categories if hasattr(g, "cat") else sorted(g.unique()):
            m = (g == lvl).values
            if m.sum() < 200 or len(np.unique(yte[m])) < 2:
                continue
            mm = metrics_at(yte[m], pt[m], thr)
            rows.append(dict(group=str(lvl), n=int(m.sum()), prevalence=float(yte[m].mean()),
                             mean_pred=float(pt[m].mean()), recall=mm["recall"], specificity=mm["specificity"],
                             roc_auc=mm["roc_auc"], brier=mm["brier"]))
        sub[gname] = rows

    # ---- reference data for explainer / OOD / drift ----
    ref = {c: float(Xtv[c].median()) for c in FEATURES}
    stats = {c: dict(mean=float(Xtv[c].mean()), std=float(Xtv[c].std()), p01=float(Xtv[c].quantile(.01)),
                     p99=float(Xtv[c].quantile(.99)), min=float(Xtv[c].min()), max=float(Xtv[c].max()))
             for c in FEATURES}
    # drift baseline: histogram of every feature on training data (fixed bin edges, for PSI)
    psi_bins = {}
    for c in FEATURES:
        edges = np.unique(np.quantile(Xtv[c], np.linspace(0, 1, 11)))
        counts = np.histogram(np.clip(Xtv[c], edges[0], edges[-1]), bins=edges)[0] / len(Xtv)
        psi_bins[c] = dict(edges=edges.tolist(), share=counts.tolist())
    bg = Xtv.sample(200, random_state=SEED)
    pop_scores = np.sort(final.predict_proba(Xtv)[:, 1])
    pct_table = np.quantile(pop_scores, np.linspace(0, 1, 101)).tolist()

    # global permutation importance (test set, AUC drop)
    from sklearn.inspection import permutation_importance
    pi = permutation_importance(final, Xte, yte, scoring="roc_auc", n_repeats=5, random_state=SEED)
    imp = sorted([dict(feature=f, mean=float(m), std=float(s)) for f, m, s in
                  zip(FEATURES, pi.importances_mean, pi.importances_std)], key=lambda d: -d["mean"])

    # second, structurally different model -> disagreement is a cheap uncertainty signal
    lr = clone(fitted["Logistic Regression"]).fit(Xtv, ytv)
    joblib.dump(lr, ROOT / "models" / "cardiac_logreg.joblib")
    Z = Xtv.values.astype(float)
    mahal = dict(mean=Z.mean(0).tolist(), inv_cov=np.linalg.pinv(np.cov(Z, rowvar=False)).tolist())
    ood_d = np.sqrt(np.einsum("ij,jk,ik->i", Z - Z.mean(0), np.array(mahal["inv_cov"]), Z - Z.mean(0)))
    mahal["p99"] = float(np.quantile(ood_d, 0.99)); mahal["p999"] = float(np.quantile(ood_d, 0.999))
    joblib.dump(final, ROOT / "models" / "cardiac_model.joblib")
    bg.to_csv(ROOT / "models" / "background_sample.csv", index=False)
    out = dict(
        best_model=best, features=FEATURES, n_rows=int(len(df)), data_audit=audit_info,
        split=dict(train=len(Xtr), validation=len(Xva), test=len(Xte), seed=SEED),
        prevalence=float(y.mean()), threshold=thr, threshold_youden=thr_youden,
        threshold_rule="maximise F1 on the validation split (test set untouched)",
        cv=cvres, results=test_tbl, final_at_0_5=at_half, curves=curves,
        calibration=dict(frac_pos=fr.round(4).tolist(), mean_pred=mp.round(4).tolist()),
        subgroups=sub, permutation_importance=imp, reference=ref, feature_stats=stats,
        psi_bins=psi_bins, mahalanobis=mahal, risk_percentiles=pct_table,
        original_baseline=dict(accuracy=0.7417, roc_auc=0.8045, f1=0.7267, brier=0.1790,
                               protocol="80/20 split, 0.5 threshold, no CV (from the original README/metrics file)"),
        runtime_sec=round(time.time() - t0, 1),
    )
    json.dump(out, open(ROOT / "models" / "cardiac_metrics.json", "w"), indent=1)
    print("TEST (final model):", {k: round(v, 4) for k, v in test_tbl[best].items() if isinstance(v, float)})
    print("runtime", out["runtime_sec"], "s")


if __name__ == "__main__":
    main()
