# 5-minute demo script & jury Q&A (all numbers are from `models/cardiac_metrics.json`)

**Framing:** Tie to the datathon's AI-for-good theme: *earlier, explainable, auditable cardiovascular screening outreach for under-resourced programmes.* Say it is decision support, not diagnosis.

| Time | Show | Say |
|---|---|---|
| 0:00 | Slide: problem | Cardiovascular disease is a leading cause of death; outreach capacity is limited. Who do we contact first, and can we justify why? |
| 0:30 | Assess tab, demo values (labelled) | Enter a 55-yo with BP 145/92 -> risk gauge, flagged at the 0.39 screening threshold. |
| 1:15 | Shapley bars + uncertainty box | Systolic BP is the main driver (it is also the top global feature). Change age to 19/height 121 -> out-of-distribution warning fires. |
| 2:00 | What-if chips | "Bring BP to 120/80" lowers the *model score*; this is association, not a proven treatment effect. |
| 2:30 | Cohort tab, synthetic sample, capacity 150 | 4-way risk x observed-cost map; compare 3 allocation strategies; fairness table shows who gets slots; drift panel. |
| 3:45 | Model evidence tab | AUC 0.805 (honest: ≈ baseline 0.8045); CV, PR curve, calibration, confusion matrix, subgroup table. |
| 4:30 | Limits + roadmap | Public dataset, no external validation, insurance model audited and demoted. Next: local validation, XGBoost/SHAP when network available, LLM narrative layer. |

## Architecture
```
Browser (HTML/JS, SVG charts) -> Flask API (validation, headers, limits)
   -> engine.py: validated schema -> HistGradientBoosting (cardiac) + LogReg (2nd opinion)
        -> Shapley explainer | OOD/uncertainty | what-if | segmentation | outreach sim | fairness | PSI drift
   models/ (joblib + metrics JSON from train_cardiac.py)    legacy insurance RF -> experimental, isolated
```

## Evaluation table (test n = 13,682)
| Model | CV AUC (train) | Test AUC | Brier |
|---|---|---|---|
| Logistic Regression | 0.791 | 0.796 | 0.185 |
| Random Forest | 0.800 | 0.804 | 0.179 |
| Extra Trees | 0.798 | 0.803 | 0.183 |
| **Hist Gradient Boosting (selected)** | **0.801** | **0.805** | **0.179** |

## Likely jury questions
1. **Accuracy only 74% - why?** Dataset ceiling: four different model families all reach CV AUC ≈ 0.80. We report that instead of inflating results; the leakage-safe pipeline reproduces the baseline.
2. **Did you improve the model?** Not in discrimination (0.8045 -> 0.8052). We improved rigour, calibration, threshold choice (validation-based) and added explainability/uncertainty.
3. **Is the cost estimate reliable?** No. We audited it: 95% of importance is an input cost column, target/units undocumented, saturates at ~4.9k. It is isolated and unused in decisions; segmentation uses observed cost.
4. **Cost savings / lives saved?** Not claimed. The simulator multiplies modelled risk by an *assumed* effect the user sets, and is labelled hypothetical.
5. **Is it fair?** We report subgroup AUC/recall/specificity and cohort-vs-selected shares. One threshold yields different error trade-offs by age (e.g. 55-64 has low specificity). Only sex/age/BMI are available; no ethnicity or income.
6. **Is SHAP used?** We implemented our own permutation-Shapley estimator (additive, unit-tested) because the library could not be installed offline.
7. **Privacy?** In-memory only, no logging of inputs, strict validation, CSV-injection guard, non-root container.
8. **Generalises to India?** Unknown - single public dataset with no external validation; local validation is the first next step.
9. **Where is IBM tech / LLM / PyTorch+XGBoost?** Not implemented (no network in build). Honest roadmap: XGBoost + SHAP comparison, Granite-generated plain-language explanation of Shapley output with guardrails, Code Engine deployment.
