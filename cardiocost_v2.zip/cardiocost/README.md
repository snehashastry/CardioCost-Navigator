# CardioCost Navigator 🫀 (v2)
Explainable cardiac-risk screening + outreach planning. **Decision support, not diagnosis.** See `METHODOLOGY.md` for evidence and limits.

## What changed from v1
| Area | v1 | v2 |
|---|---|---|
| Training | single split, 2 models, threshold 0.5 | leakage-safe 60/20/20, 5-fold CV, 4 model families, validation-chosen threshold, test used once |
| Metrics | acc/AUC/F1/Brier | + precision, recall, specificity, PR-AUC, confusion matrix, calibration, subgroups, permutation importance |
| Insurance RF | shown as the cost estimate | audited (`audit_insurance.py`): unvalidated, 95% driven by an input → experimental only; segmentation uses observed cost |
| Explainability | counterfactual only | + own permutation-Shapley (additive, tested), global importance |
| Safety | clamped bad inputs silently | strict validation (422 with reasons), OOD/uncertainty warnings, drift (PSI) |
| Cohort | scores + top 10 | + outreach simulator (3 strategies, assumed-effect), fairness breakdown, per-row validation report |
| Engineering | global "last result" (cross-user leak), no tests | per-token in-memory results, CSV formula-injection guard, limits, headers, 30+ tests, non-root Docker |

## Real results (test set n=13,682; reproduce with `python train_cardiac.py`)
ROC-AUC **0.805** (baseline 0.8045), PR-AUC 0.787, Brier 0.179, accuracy 0.741 @0.5 / 0.725 @0.39, recall 0.79 @0.39.
**Discrimination did not materially improve** - this dataset appears capped near AUC 0.80. Gains are rigour and transparency.

## Run
```bash
pip install -r requirements.txt
python train_cardiac.py      # ~70 s; regenerates models/ + metrics (optional)
python make_sample.py        # optional: regenerate SYNTHETIC cohort
python audit_insurance.py    # optional: regenerate insurance audit
python -m unittest discover -s tests -v
python app.py                # http://localhost:5000
# Docker / Podman:
docker build -t cardiocost . && docker run -p 8080:8080 cardiocost
```

## API
`POST /api/assess` (11 core fields required) · `POST /api/whatif` · `POST /api/batch` (multipart: file, capacity, strategy, effect) ·
`GET /api/batch/download/<token>` · `GET /api/model` · `GET /api/methodology` · `GET /healthz`

## Not done / honest gaps
XGBoost, PyTorch, SHAP and an LLM (e.g. IBM Granite) layer were **not** added: the build sandbox had no network, and nothing unverified was shipped.
The Docker image was not built here (no Docker daemon) - run the commands above. No external validation, no clinical validation, no real cost data.
