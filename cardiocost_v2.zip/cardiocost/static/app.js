const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const pct=x=>(x*100).toFixed(1)+"%", money=x=>Math.round(x).toLocaleString("en-IN");
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const NUM=["age","height","weight","systolic_bp","diastolic_bp","income","household_size","dependents","hospitalizations_last_3yrs","days_hospitalized_last_3yrs","medication_count","annual_medical_cost"];
const SEL=["sex","cholesterol","gluc","smoker","alcohol","active"];
const CHK=["hypertension","diabetes","asthma","cardiovascular_disease","cancer_history","kidney_disease","liver_disease","arthritis"];
const COL={critical:"#fb7185",hidden:"#fbbf24",review:"#60a5fa",healthy:"#2dd4bf"};
const NAME={critical:"Critical",hidden:"Hidden risk",review:"Cost review",healthy:"Healthy"};
let modelLoaded=false;
const post=(u,b)=>fetch(u,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)});

$$("nav button").forEach(b=>b.onclick=()=>{$$("nav button").forEach(x=>x.classList.remove("on"));b.classList.add("on");
  $$(".tab").forEach(t=>t.classList.add("hide"));$("#"+b.dataset.t).classList.remove("hide");
  if(b.dataset.t==="t3"&&!modelLoaded)loadModel()});

function payload(){const o={};NUM.concat(SEL).forEach(k=>o[k]=$("#"+k).value);CHK.forEach(k=>o[k]=$("#"+k).checked?1:0);return o}
["systolic_bp","diastolic_bp"].forEach(k=>$("#"+k).addEventListener("change",()=>{
  if(+$("#systolic_bp").value>=140||+$("#diastolic_bp").value>=90)$("#hypertension").checked=true}));

function gauge(r,thr){const a=Math.PI*(1-r),x=100+80*Math.cos(a),y=100-80*Math.sin(a);
  const col=r>=.6?"#fb7185":r>=.35?"#fbbf24":"#2dd4bf";
  return `<svg viewBox="0 0 200 118" width="100%" style="max-width:260px" role="img" aria-label="Modelled risk ${pct(r)}">
  <path d="M20 100A80 80 0 0 1 180 100" fill="none" stroke="#243252" stroke-width="16" stroke-linecap="round"/>
  <path d="M20 100A80 80 0 0 1 ${x} ${y}" fill="none" stroke="${col}" stroke-width="16" stroke-linecap="round"/>
  <text x="100" y="96" text-anchor="middle" font-size="30" font-weight="700" fill="#e8eefc">${Math.round(r*100)}%</text></svg>`}

async function assess(){
  const btn=$("#go"),ve=$("#verr");btn.disabled=true;ve.classList.add("hide");
  try{
    const res=await post("/api/assess",payload());const d=await res.json();
    if(!res.ok){ve.innerHTML=esc(d.error)+"<br>"+(d.details||[]).map(esc).join("<br>");ve.classList.remove("hide");return}
    render(d);
  }catch(e){ve.textContent="Network error - please retry.";ve.classList.remove("hide")}
  finally{btn.disabled=false}
}
function shapBars(sh){
  const m=Math.max(.02,...sh.contributions.map(c=>Math.abs(c.shap)));
  return sh.contributions.slice(0,8).map(c=>{const w=Math.abs(c.shap)/m*50,pos=c.shap>=0;
    return `<div class="sbar"><span class="n">${esc(c.label)} <span class="note">${+c.value.toFixed(1)}</span></span><span class="tr"><i style="${pos?`left:50%`:`right:50%`};width:${w}%;background:${pos?"#fb7185":"#2dd4bf"}"></i></span><span class="p">${c.shap>=0?"+":""}${(c.shap*100).toFixed(1)} pt</span></div>`}).join("")}
function render(d){
  const u=d.uncertainty,ex=d.insurance_experimental;
  $("#out").innerHTML=`
  <div class="kpis">
   <div class="kpi"><div class="l">Modelled cardiac risk (screening signal)</div>${gauge(d.risk)}<span class="pill ${d.tier}">${d.tier}</span> <span class="note">${d.flagged?"flagged":"not flagged"} at threshold ${pct(d.threshold)}</span>
     <div class="note" style="margin-top:6px">Higher than ${d.population_percentile}% of the training population</div></div>
    <div class="kpi"><div class="l">Segment (observed prior-year cost vs cohort split)</div><div class="seg ${d.segment.id}" style="margin-top:8px"><b>${esc(d.segment.name)}</b><br><span class="note" style="color:var(--tx)">${esc(d.segment.action)}</span></div></div>
  </div>
  <div>${u.level==="ok"&&!u.warnings.length?'<div class="uw ok">Inputs are within the range of the training data; the two reference models agree.</div>':u.warnings.map(w=>`<div class="uw ${w.level}">${esc(w.msg)}</div>`).join("")}</div>
  ${d.flags.length?`<div style="margin:10px 0">${d.flags.map(f=>`<span class="flag">${esc(f)}</span>`).join("")}</div>`:""}
  <div class="two" style="margin-top:12px">
   <div><h2>Why the model says this (Shapley)</h2><div class="note">Points of probability added (red) or removed (teal) vs. an average patient (${pct(d.shap.base)}) &rarr; ${pct(d.shap.prediction)}</div>${shapBars(d.shap)}<div class="note">${esc(d.shap.note)}</div></div>
   <div><h2>Model-based what-if</h2><div class="chips" id="chips"></div><div id="wi" class="note">Select scenarios&hellip;</div><div class="note" id="wicav" style="margin-top:6px"></div></div>
  </div>
  <details><summary>Experimental insurance-cost output (unvalidated - do not rely on it)</summary>
   <p>Legacy model output: <b>${money(ex.estimate)}</b> <span class="note">(unit: ${esc(ex.unit)})</span></p><ul class="note">${ex.reasons.map(r=>`<li>${esc(r)}</li>`).join("")}</ul></details>
  <p class="note" style="margin-top:12px">${esc(d.disclaimer)}</p>`;
  post("/api/whatif",{inputs:payload(),scenarios:[]}).then(r=>r.json()).then(w=>{
    $("#wicav").textContent=w.caveat;
    $("#chips").innerHTML=w.singles.map(s=>`<label><input type="checkbox" value="${esc(s.id)}"> ${esc(s.label)} <span class="note">(${s.reduction>0?"-":"+"}${Math.abs(s.reduction*100).toFixed(1)} pt)</span></label>`).join("");
    $$("#chips input").forEach(c=>c.onchange=()=>sim(w.base));});
}
async function sim(base){
  const ch=$$("#chips input:checked").map(c=>c.value);
  if(!ch.length){$("#wi").textContent="Select scenarios\u2026";return}
  const w=await (await post("/api/whatif",{inputs:payload(),scenarios:ch})).json();
  $("#wi").innerHTML=`<div style="font-size:26px;font-weight:700;color:var(--tx)">${pct(base)} &rarr; <span style="color:var(--teal)">${pct(w.combined)}</span></div><div class="note">Modelled score change, not a predicted treatment effect</div>`;
}
$("#go").onclick=assess;

/* ---------------- cohort ---------------- */
async function batch(file){
  const fd=new FormData();fd.append("file",file);fd.append("capacity",$("#cap").value);fd.append("strategy",$("#strat").value);fd.append("effect",$("#eff").value);
  $("#bout").innerHTML='<div class="empty">Scoring&hellip;</div>';
  let res,d;try{res=await fetch("/api/batch",{method:"POST",body:fd});d=await res.json()}catch(e){$("#bout").innerHTML='<div class="warn">Network error.</div>';return}
  if(!res.ok){$("#bout").innerHTML=`<div class="warn" role="alert">${esc(d.error)}<br>${(d.details||[]).map(esc).join("<br>")}</div>`;return}
  window.LASTFILE=file;
  const maxc=Math.max(...d.points.map(p=>p.observed_cost)),minc=Math.min(...d.points.map(p=>p.observed_cost));
  const X=r=>40+r*420,Y=c=>260-(c-minc)/(maxc-minc||1)*230,sx=X(.5),sy=Y(d.cost_split);
  const dots=d.points.map(p=>`<circle cx="${X(p.cardiac_risk)}" cy="${Y(p.observed_cost)}" r="3" fill="${COL[p.segment]}" opacity=".6"/>`).join("");
  const o=d.outreach;
  $("#bout").innerHTML=`<div class="kpis">
   <div class="kpi"><div class="l">Members scored</div><div class="v">${d.n.toLocaleString()}</div>${d.n_rejected?`<div class="note" style="color:var(--amber)">${d.n_rejected} rows rejected by validation</div>`:""}</div>
   <div class="kpi"><div class="l">Mean modelled risk</div><div class="v">${pct(d.mean_risk)}</div></div>
   <div class="kpi"><div class="l">Flagged at threshold</div><div class="v">${pct(d.flagged_share)}</div></div>
   <div class="kpi"><div class="l">Hidden-risk members</div><div class="v" style="color:var(--amber)">${d.segments.hidden||0}</div></div></div>
  ${d.drift_alert?'<div class="warn" role="alert">Data drift: at least one feature distribution differs significantly from the training data (PSI &gt; 0.25). Model performance on this cohort may be lower than reported.</div>':""}
  <div class="two"><div class="card"><h2>Risk &times; observed-cost map</h2>
   <svg viewBox="0 0 480 290" width="100%" role="img" aria-label="Scatter of modelled risk versus observed cost"><line x1="40" y1="${sy}" x2="460" y2="${sy}" stroke="#243252" stroke-dasharray="4"/><line x1="${X(+(window.THR||.39))}" y1="30" x2="${X(+(window.THR||.39))}" y2="260" stroke="#243252" stroke-dasharray="4"/>
   ${dots}<text x="250" y="284" fill="#8fa1c7" font-size="11" text-anchor="middle">Modelled risk &rarr;</text><text x="12" y="150" fill="#8fa1c7" font-size="11" transform="rotate(-90 12 150)">Observed cost &rarr;</text></svg>
   <div class="note">${Object.entries(COL).map(([k,c])=>`<span style="color:${c}">&#9679;</span> ${NAME[k]} (${d.segments[k]||0})`).join(" &nbsp; ")}</div></div>
   <div class="card"><h2>Top 10 by risk &times; cost</h2><table><tr><th>Member</th><th>Risk</th><th>Cost</th><th>Segment</th></tr>
   ${d.top.map(t=>`<tr><td>${esc(t.member_id)}</td><td>${pct(t.cardiac_risk)}</td><td>${money(t.observed_cost)}</td><td style="color:${COL[t.segment]}">${NAME[t.segment]}</td></tr>`).join("")}</table>
   <p><a class="btn ghost" href="/api/batch/download/${encodeURIComponent(d.token)}">Download scored CSV</a></p></div></div>
  <div class="card"><h2>Outreach allocation simulator <span class="syn">hypothetical</span></h2>
   <p class="note">${esc(o.caveat)}</p>
   <table><tr><th>Strategy (capacity ${o.capacity})</th><th>Mean risk of reached</th><th>Flagged reached</th><th>Hypothetical cases averted*</th></tr>
   ${d.outreach_compare.map(s=>`<tr${s.strategy===o.strategy?' style="background:#18243d"':''}><td>${esc(s.strategy_label)}</td><td>${pct(s.mean_risk_reached)}</td><td>${pct(s.share_of_flagged_reached)}</td><td>${s.hypothetical_cases_averted.toFixed(1)}</td></tr>`).join("")}</table>
   <p class="note">*Sum of modelled risk among reached &times; assumed effect (${pct(o.assumed_effect)}), out of ${o.cohort_expected_cases.toFixed(0)} modelled cohort cases. Not a savings or outcome estimate. Change inputs above and re-run.</p></div>
  <div class="two"><div class="card"><h2>Who gets the slots? (fairness check)</h2><table><tr><th>Group</th><th>Cohort</th><th>Selected</th><th>Mean risk</th></tr>
   ${d.fairness.map(f=>`<tr><td>${esc(f.group)}: ${esc(f.level)}</td><td>${pct(f.cohort_share)}</td><td>${pct(f.selected_share)}</td><td>${pct(f.mean_risk)}</td></tr>`).join("")}</table>
   <p class="note">Large gaps between cohort and selected share show which groups a strategy under- or over-serves. Equal shares are not automatically fair - risk differs by group.</p></div>
   <div class="card"><h2>Drift monitor (PSI vs training)</h2><table><tr><th>Feature</th><th>PSI</th><th>Status</th></tr>
   ${d.drift.slice(0,6).map(f=>`<tr><td>${esc(f.label)}</td><td>${f.psi.toFixed(3)}</td><td style="color:${f.status==="significant"?"#fb7185":f.status==="moderate"?"#fbbf24":"#2dd4bf"}">${f.status}</td></tr>`).join("")}</table>
   <p class="note">PSI &lt; 0.1 stable, 0.1-0.25 moderate, &gt; 0.25 significant shift. Input drift only; cannot detect label drift without outcomes.</p></div></div>`;
}
$("#file").onchange=e=>e.target.files[0]&&batch(e.target.files[0]);
$("#sample").onclick=async()=>batch(await (await fetch("/sample.csv")).blob().then(b=>new File([b],"sample.csv")));
["cap","strat","eff"].forEach(k=>$("#"+k).addEventListener("change",()=>window.LASTFILE&&batch(window.LASTFILE)));

/* ---------------- model evidence ---------------- */
function line(pts,col){return `<polyline points="${pts}" fill="none" stroke="${col}" stroke-width="2.2"/>`}
function curveSvg(c,kind,xl,yl){const k=kind==="roc"?["fpr","tpr"]:["recall","precision"];
  const cols=["#2dd4bf","#60a5fa","#fbbf24","#fb7185"];let i=0,s="";
  for(const [n,v] of Object.entries(c)){const cc=v[kind];s+=line(cc[k[0]].map((x,j)=>`${40+x*230},${260-cc[k[1]][j]*230}`).join(" "),cols[i%4]);i++}
  return `<svg viewBox="0 0 290 300" width="100%" role="img" aria-label="${kind} curves">${kind==="roc"?'<line x1="40" y1="260" x2="270" y2="30" stroke="#243252" stroke-dasharray="4"/>':""}<rect x="40" y="30" width="230" height="230" fill="none" stroke="#243252"/>
   <text x="155" y="286" fill="#8fa1c7" font-size="11" text-anchor="middle">${xl}</text><text x="12" y="150" fill="#8fa1c7" font-size="11" transform="rotate(-90 12 150)">${yl}</text></svg>`}
function calSvg(c){const pts=c.mean_pred.map((x,i)=>`${40+x*230},${260-c.frac_pos[i]*230}`).join(" ");
  return `<svg viewBox="0 0 290 300" width="100%" role="img" aria-label="Calibration curve"><line x1="40" y1="260" x2="270" y2="30" stroke="#243252" stroke-dasharray="4"/><rect x="40" y="30" width="230" height="230" fill="none" stroke="#243252"/>${line(pts,"#2dd4bf")}
   ${c.mean_pred.map((x,i)=>`<circle cx="${40+x*230}" cy="${260-c.frac_pos[i]*230}" r="3" fill="#2dd4bf"/>`).join("")}
   <text x="155" y="286" fill="#8fa1c7" font-size="11" text-anchor="middle">Mean predicted risk</text><text x="12" y="150" fill="#8fa1c7" font-size="11" transform="rotate(-90 12 150)">Observed fraction</text></svg>`}
async function loadModel(){
  let m;try{m=await (await fetch("/api/model")).json()}catch(e){$("#mout").innerHTML='<div class="warn">Could not load evaluation.</div>';return}
  modelLoaded=true;window.THR=m.threshold;
  const b=m.best_model,r=m.results[b],h=m.final_at_0_5,o=m.original_baseline,cm=r.confusion;
  const f=(x)=>x.toFixed(3);
  const rows=Object.entries(m.results).map(([n,v])=>`<tr${n===b?' style="background:#18243d"':''}><td>${esc(n)}${n===b?" &#10003;":""}</td><td>${f(m.cv[n].cv_roc_auc_mean)} &plusmn; ${f(m.cv[n].cv_roc_auc_std)}</td><td>${f(v.roc_auc)}</td><td>${f(v.pr_auc)}</td><td>${f(v.accuracy)}</td><td>${f(v.recall)}</td><td>${f(v.specificity)}</td><td>${f(v.f1)}</td><td>${f(v.brier)}</td></tr>`).join("");
  const sg=Object.entries(m.subgroups).map(([g,rs])=>rs.map(x=>`<tr><td>${esc(g)}: ${esc(x.group)}</td><td>${x.n}</td><td>${pct(x.prevalence)}</td><td>${pct(x.mean_pred)}</td><td>${f(x.roc_auc)}</td><td>${f(x.recall)}</td><td>${f(x.specificity)}</td></tr>`).join("")).join("");
  const mx=Math.max(...m.importance.map(i=>i.auc_drop));
  $("#mout").innerHTML=`
  <div class="card"><h2>Honest comparison (held-out test set, evaluated once)</h2>
   <p>Selected: <b>${esc(b)}</b> &middot; split ${m.split.train.toLocaleString()} train / ${m.split.validation.toLocaleString()} validation / ${m.split.test.toLocaleString()} test &middot; ${esc(m.threshold_rule)}: threshold <b>${m.threshold.toFixed(2)}</b></p>
   <div style="overflow-x:auto"><table><tr><th>Model</th><th>CV AUC (train)</th><th>Test AUC</th><th>PR-AUC</th><th>Acc.</th><th>Recall</th><th>Spec.</th><th>F1</th><th>Brier</th></tr>${rows}</table></div>
   <p class="note">Original baseline (${esc(o.protocol)}): accuracy ${o.accuracy}, ROC-AUC ${o.roc_auc}, F1 ${o.f1}, Brier ${o.brier}. Rebuilt pipeline at the conventional 0.5 threshold: accuracy ${f(h.accuracy)}, ROC-AUC ${f(h.roc_auc)}, F1 ${f(h.f1)}, Brier ${f(h.brier)}. <b>Discrimination is essentially unchanged - this dataset appears to cap near AUC 0.80.</b> The gain is rigour (no leakage, CV, validation-chosen threshold, calibration, subgroups), not a higher score.</p></div>
  <div class="two"><div class="card"><h2>ROC (test)</h2>${curveSvg(m.curves,"roc","False positive rate","True positive rate")}</div><div class="card"><h2>Precision-Recall (test)</h2>${curveSvg(m.curves,"pr","Recall","Precision")}</div></div>
  <div class="note">Lines (in table order): Logistic Regression, Random Forest, Extra Trees, Hist Gradient Boosting.</div>
  <div class="two"><div class="card"><h2>Calibration (selected model, test)</h2>${calSvg(m.calibration)}<div class="note">Points near the diagonal mean predicted risk matches observed frequency.</div></div>
   <div class="card"><h2>Confusion matrix (test, threshold ${m.threshold.toFixed(2)})</h2><table style="text-align:center"><tr><th></th><th>Pred. no disease</th><th>Pred. disease</th></tr><tr><th>Actual no</th><td>${cm[0][0]}</td><td>${cm[0][1]}</td></tr><tr><th>Actual yes</th><td>${cm[1][0]}</td><td>${cm[1][1]}</td></tr></table>
   <h2 style="margin-top:18px">Global importance (AUC drop when shuffled)</h2>${m.importance.slice(0,6).map(i=>`<div class="bar"><span class="n">${esc(i.label)}</span><span class="t"><i style="width:${Math.max(0,i.auc_drop)/mx*100}%;background:#60a5fa"></i></span><span class="p">${i.auc_drop.toFixed(3)}</span></div>`).join("")}</div></div>
  <div class="card"><h2>Subgroup performance (test)</h2><div style="overflow-x:auto"><table><tr><th>Group</th><th>n</th><th>Prevalence</th><th>Mean pred.</th><th>AUC</th><th>Recall</th><th>Spec.</th></tr>${sg}</table></div>
   <p class="note">One global threshold gives different error trade-offs by group (e.g. high recall but low specificity at 55-64). Subgroups are limited to attributes in the dataset; no ethnicity/income data.</p></div>
  <div class="card"><h2>Data audit</h2><p class="note">${esc(JSON.stringify(m.data_audit))}</p></div>`;
}
