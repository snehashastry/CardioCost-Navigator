"""Unit + API tests.  Run:  python -m unittest discover -s tests -v   (also works with pytest)"""
import io, json, os, sys, unittest, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np, pandas as pd
import engine, app as appmod

GOOD = dict(age=55, sex=1, height=172, weight=85, systolic_bp=145, diastolic_bp=92, cholesterol=2, gluc=1, smoker=0, alcohol=0, active=1)
SAMPLE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "sample", "sample_members_SYNTHETIC.csv")


class EngineTests(unittest.TestCase):
    def test_validate_ok_and_bmi(self):
        p = engine.validate(GOOD); self.assertAlmostEqual(p["bmi"], 85 / 1.72 ** 2, places=1)
    def test_validate_rejects_bad(self):
        for bad in [dict(GOOD, age="abc"), dict(GOOD, systolic_bp=300), dict(GOOD, sex=2), dict(GOOD, weight=float("nan")),
                    dict(GOOD, diastolic_bp=150, systolic_bp=140), dict(GOOD, cholesterol=1.5)]:
            with self.assertRaises(engine.ValidationError): engine.validate(bad, strict_core=True)
    def test_missing_core_field_rejected(self):
        with self.assertRaises(engine.ValidationError): engine.validate({k: v for k, v in GOOD.items() if k != "age"}, strict_core=True)
    def test_feature_order_matches_model(self):
        fr = engine._cardiac_frame([engine.validate(GOOD)]); self.assertEqual(list(fr.columns), engine.CARDIAC_FEATURES)
    def test_risk_monotone_in_bp(self):
        lo = engine.cardiac_risk([engine.validate(dict(GOOD, systolic_bp=110, diastolic_bp=70))])[0]
        hi = engine.cardiac_risk([engine.validate(dict(GOOD, systolic_bp=170, diastolic_bp=100))])[0]
        self.assertGreater(hi, lo)
    def test_shapley_additive(self):
        r = engine.assess(GOOD); s = r["shap"]
        self.assertAlmostEqual(s["base"] + sum(c["shap"] for c in s["contributions"]), r["risk"], places=6)
    def test_ood_warning(self):
        r = engine.assess(dict(GOOD, age=19, height=121, weight=240)); self.assertNotEqual(r["uncertainty"]["level"], "ok")
    def test_segment_uses_observed_cost(self):
        self.assertEqual(engine.segment(0.9, 0, 100)["id"], "hidden"); self.assertEqual(engine.segment(0.9, 500, 100)["id"], "critical")
        self.assertEqual(engine.segment(0.05, 500, 100)["id"], "review"); self.assertEqual(engine.segment(0.05, 0, 100)["id"], "healthy")
    def test_insurance_flagged_unreliable(self):
        self.assertFalse(engine.assess(GOOD)["insurance_experimental"]["reliable"])
    def test_whatif_bp_reduces_risk(self):
        w = engine.whatif(engine.validate(GOOD), ["bp_control"]); self.assertLess(w["combined"], w["base"])
    def test_psi_same_dist_small(self):
        from train_cardiac import load_clean, FEATURES
        df = load_clean().sample(3000, random_state=1)[FEATURES]
        self.assertLess(max(d["psi"] for d in engine.psi_report(df)), 0.1)
    def test_psi_detects_shift(self):
        from train_cardiac import load_clean, FEATURES
        df = load_clean().sample(3000, random_state=1)[FEATURES].copy(); df["ap_hi"] = df["ap_hi"] + 40
        self.assertEqual(engine.psi_report(df)[0]["status"], "significant")
    def test_outreach_capacity_and_ordering(self):
        sc = pd.DataFrame(dict(cardiac_risk=[.9, .8, .2, .1], flagged=[True, True, False, False], observed_cost=[10, 9000, 8000, 5], sex=[0, 1, 0, 1], age=[50] * 4))
        o = engine.outreach_simulation(sc, 2, "risk", .2); self.assertEqual(o["reached"], 2); self.assertAlmostEqual(o["hypothetical_cases_averted"], 1.7 * .2)
        with self.assertRaises(ValueError): engine.outreach_simulation(sc, 2, "nope", .2)


class ApiTests(unittest.TestCase):
    def setUp(self): self.c = appmod.app.test_client()
    def csv(self, df): return (io.BytesIO(df.to_csv(index=False).encode()), "x.csv")

    def test_health_and_index(self):
        self.assertEqual(self.c.get("/healthz").status_code, 200); self.assertEqual(self.c.get("/").status_code, 200)
    def test_assess_ok(self):
        r = self.c.post("/api/assess", json=GOOD); self.assertEqual(r.status_code, 200); d = r.get_json()
        self.assertTrue(0 <= d["risk"] <= 1); self.assertIn("shap", d); self.assertNotIn("traceback", json.dumps(d).lower())
    def test_assess_invalid_422(self):
        r = self.c.post("/api/assess", json=dict(GOOD, age=-5)); self.assertEqual(r.status_code, 422); self.assertTrue(r.get_json()["details"])
    def test_assess_non_json(self):
        self.assertEqual(self.c.post("/api/assess", data="nope", content_type="text/plain").status_code, 422)
        self.assertEqual(self.c.post("/api/assess", json=[1, 2]).status_code, 422)
    def test_whatif(self):
        r = self.c.post("/api/whatif", json=dict(inputs=GOOD, scenarios=["bp_control"])); self.assertEqual(r.status_code, 200)
        self.assertEqual(self.c.post("/api/whatif", json=dict(inputs=GOOD, scenarios=["hack"])).status_code, 422)
    def test_batch_sample(self):
        r = self.c.post("/api/batch", data=dict(file=(open(SAMPLE, "rb"), "s.csv"), capacity="100", strategy="hidden"), content_type="multipart/form-data")
        d = r.get_json(); self.assertEqual(r.status_code, 200); self.assertEqual(d["n"], 1500); self.assertEqual(d["outreach"]["reached"], 100)
        dl = self.c.get("/api/batch/download/" + d["token"]); self.assertEqual(dl.status_code, 200); self.assertIn(b"cardiac_risk", dl.data)
    def test_batch_download_unknown_token(self):
        self.assertEqual(self.c.get("/api/batch/download/nope").status_code, 404)
    def test_batch_rejects_non_csv_and_missing_cols(self):
        self.assertEqual(self.c.post("/api/batch", data=dict(file=(io.BytesIO(b"x"), "a.txt")), content_type="multipart/form-data").status_code, 400)
        self.assertEqual(self.c.post("/api/batch", content_type="multipart/form-data", data={}).status_code, 400)
        r = self.c.post("/api/batch", data=dict(file=self.csv(pd.DataFrame(dict(age=[50])))), content_type="multipart/form-data")
        self.assertEqual(r.status_code, 422); self.assertIn("sex", r.get_json()["details"])
    def test_batch_reports_bad_rows(self):
        df = pd.DataFrame([GOOD, dict(GOOD, age=500), dict(GOOD, systolic_bp="x")]); df["member_id"] = ["=CMD()", "b", "c"]
        r = self.c.post("/api/batch", data=dict(file=self.csv(df)), content_type="multipart/form-data"); d = r.get_json()
        self.assertEqual((d["n"], d["n_rejected"]), (1, 2))
        csv = self.c.get("/api/batch/download/" + d["token"]).data.decode(); self.assertIn("'=CMD()", csv)
    def test_batch_all_invalid(self):
        df = pd.DataFrame([dict(GOOD, age=500)]); r = self.c.post("/api/batch", data=dict(file=self.csv(df)), content_type="multipart/form-data")
        self.assertEqual(r.status_code, 422)
    def test_batch_binary_masquerading(self):
        r = self.c.post("/api/batch", data=dict(file=(io.BytesIO(b"PK\x03\x04" + b"\x00" * 50), "a.csv")), content_type="multipart/form-data")
        self.assertEqual(r.status_code, 400)
    def test_batch_bad_params(self):
        r = self.c.post("/api/batch", data=dict(file=(open(SAMPLE, "rb"), "s.csv"), effect="3"), content_type="multipart/form-data"); self.assertEqual(r.status_code, 400)
    def test_upload_limit(self):
        big = io.BytesIO(b"a," * (6 * 1024 * 1024))
        self.assertEqual(self.c.post("/api/batch", data=dict(file=(big, "b.csv")), content_type="multipart/form-data").status_code, 413)
    def test_security_headers(self):
        h = self.c.get("/").headers; self.assertEqual(h["X-Content-Type-Options"], "nosniff"); self.assertIn("default-src", h["Content-Security-Policy"])
    def test_model_endpoint_uses_real_metrics(self):
        d = self.c.get("/api/model").get_json(); m = json.load(open(os.path.join(os.path.dirname(appmod.__file__), "models", "cardiac_metrics.json")))
        self.assertEqual(d["results"][d["best_model"]]["roc_auc"], m["results"][m["best_model"]]["roc_auc"])
    def test_methodology_download(self):
        self.assertEqual(self.c.get("/api/methodology").status_code, 200)


if __name__ == "__main__":
    unittest.main()
