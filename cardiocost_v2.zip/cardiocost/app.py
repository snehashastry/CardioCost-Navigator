"""CardioCost Navigator - Flask app (v2: validated inputs, explainability, uncertainty, drift, outreach simulation)."""
from __future__ import annotations

import io
import json
import os
import secrets
from collections import OrderedDict
from pathlib import Path

import numpy as np
import pandas as pd
from flask import Flask, abort, jsonify, render_template, request, send_file, send_from_directory

import engine

ROOT = Path(__file__).resolve().parent
MAX_ROWS = 20000
MAX_UPLOAD = 5 * 1024 * 1024
RESULT_CACHE: "OrderedDict[str, str]" = OrderedDict()  # token -> scored CSV text (in-memory, capped, never written to disk)
CACHE_MAX = 16

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD


@app.after_request
def secure(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["Cache-Control"] = "no-store" if request.path.startswith("/api/") else resp.headers.get("Cache-Control", "no-cache")
    resp.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; script-src 'self' 'unsafe-inline'"
    return resp


def err(msg, code=400, details=None):
    return jsonify(error=msg, details=details or []), code


@app.errorhandler(413)
def too_big(_):
    return err(f"File too large (limit {MAX_UPLOAD // 1024 // 1024} MB).", 413)


@app.errorhandler(404)
def nf(_):
    return err("Not found.", 404)


@app.errorhandler(405)
def nm(_):
    return err("Method not allowed.", 405)


@app.errorhandler(500)
def ise(_):  # never leak stack traces / patient data
    return err("Internal error.", 500)


def _json_body():
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        raise engine.ValidationError(["Request body must be a JSON object."])
    return body


@app.get("/")
def home():
    return render_template("index.html", m=engine.METRICS, defaults=engine.DEFAULTS, strategies=engine.STRATEGIES)


@app.get("/healthz")
def healthz():
    return jsonify(status="ok")


@app.get("/api/model")
def api_model():
    m = engine.METRICS
    out = {k: m[k] for k in ["best_model", "results", "final_at_0_5", "cv", "curves", "calibration", "subgroups", "split",
                             "threshold", "threshold_rule", "data_audit", "original_baseline", "n_rows"]}
    out["importance"] = engine.global_importance()
    return jsonify(out)


@app.get("/api/methodology")
def methodology():
    return send_from_directory(ROOT, "METHODOLOGY.md", mimetype="text/markdown", as_attachment=True)


@app.get("/sample.csv")
def sample_csv():
    return send_from_directory(ROOT / "sample", "sample_members_SYNTHETIC.csv", mimetype="text/csv")


@app.post("/api/assess")
def api_assess():
    try:
        return jsonify(engine.assess(_json_body()))
    except engine.ValidationError as e:
        return err("Invalid input.", 422, e.errors)


@app.post("/api/whatif")
def api_whatif():
    try:
        body = _json_body()
        p = engine.validate(body.get("inputs", {}), strict_core=True)
        sc = body.get("scenarios", [])
        if not isinstance(sc, list) or not all(isinstance(s, str) for s in sc):
            raise engine.ValidationError(["scenarios must be a list of strings"])
        unknown = [s for s in sc if s not in engine.SCENARIOS]
        if unknown:
            raise engine.ValidationError([f"unknown scenario: {u}" for u in unknown])
        return jsonify(engine.whatif(p, sc))
    except engine.ValidationError as e:
        return err("Invalid input.", 422, e.errors)


def _csv_safe(v):
    """Neutralise spreadsheet formula injection in any string we echo back."""
    return "'" + v if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r") else v


def _score(df: pd.DataFrame):
    """Validate every row; invalid rows are excluded and reported (not silently clamped)."""
    rows, keep, bad = [], [], []
    recs = df.to_dict("records")
    for i, r in enumerate(recs):
        try:
            rows.append(engine.validate(r, strict_core=True)); keep.append(i)
        except engine.ValidationError as e:
            if len(bad) < 20:
                bad.append(dict(row=i + 2, errors=e.errors[:4]))
            else:
                bad.append(None)
    n_bad = len(recs) - len(keep)
    bad = [b for b in bad if b]
    if not rows:
        raise engine.ValidationError(["No valid rows. First problems: " + "; ".join(f"row {b['row']}: {', '.join(b['errors'])}" for b in bad[:3])])
    risk = engine.cardiac_risk(rows)
    obs = np.array([r["annual_medical_cost"] for r in rows])
    ids = df["member_id"].astype(str).iloc[keep].map(_csv_safe).tolist() if "member_id" in df else [f"row{k+2}" for k in keep]
    out = pd.DataFrame(dict(member_id=ids, age=[r["age"] for r in rows], sex=[int(r["sex"]) for r in rows],
                            cardiac_risk=np.round(risk, 4), flagged=risk >= engine.THRESHOLD,
                            risk_tier=[engine.tier(r) for r in risk], observed_cost=obs,
                            segment=[engine.segment(r, c)["id"] for r, c in zip(risk, obs)]))
    out["priority_score"] = np.round(out["cardiac_risk"] * out["observed_cost"], 2)
    core = engine._cardiac_frame(rows)
    return out, core, n_bad, bad


@app.post("/api/batch")
def api_batch():
    f = request.files.get("file")
    if not f or not f.filename:
        return err("Upload a CSV file in the 'file' field.")
    if not f.filename.lower().endswith(".csv"):
        return err("Only .csv files are accepted.")
    try:
        raw = f.read(MAX_UPLOAD + 1)
        if raw[:2] in (b"PK", b"\x89P") or b"\x00" in raw[:1024]:
            return err("File does not look like a text CSV.")
        df = pd.read_csv(io.BytesIO(raw), nrows=MAX_ROWS + 1)
    except Exception:
        return err("Could not parse the file as CSV.")
    if len(df) > MAX_ROWS:
        return err(f"Too many rows (limit {MAX_ROWS:,}).")
    df.columns = [str(c).strip() for c in df.columns]
    missing = [c for c in engine.CORE if c not in df.columns]
    if missing:
        return err("CSV is missing required columns.", 422, missing)
    capacity = request.form.get("capacity", type=int)
    strategy = request.form.get("strategy", "risk")
    effect = request.form.get("effect", default=0.15, type=float)
    if strategy not in engine.STRATEGIES or effect is None or not 0 <= effect <= 1:
        return err("Invalid strategy or effect (effect must be 0-1).")
    try:
        scored, core, n_bad, bad = _score(df)
    except engine.ValidationError as e:
        return err("Could not score file.", 422, e.errors)
    capacity = capacity if capacity and capacity > 0 else max(1, int(round(len(scored) * 0.1)))
    capacity = min(capacity, len(scored))

    token = secrets.token_urlsafe(16)
    RESULT_CACHE[token] = scored.to_csv(index=False)
    while len(RESULT_CACHE) > CACHE_MAX:
        RESULT_CACHE.popitem(last=False)

    top = scored.sort_values("priority_score", ascending=False).head(10)
    samp = scored.sample(min(len(scored), 600), random_state=1)
    drift = engine.psi_report(core)
    return jsonify(
        token=token, n=len(scored), n_rejected=n_bad, rejected_examples=bad[:5],
        segments=scored["segment"].value_counts().to_dict(), mean_risk=float(scored["cardiac_risk"].mean()),
        flagged_share=float(scored["flagged"].mean()), cost_split=engine.CFG["cost_split"],
        top=top[["member_id", "cardiac_risk", "observed_cost", "segment"]].to_dict("records"),
        points=samp[["cardiac_risk", "observed_cost", "segment"]].to_dict("records"),
        drift=drift, drift_alert=any(d["status"] == "significant" for d in drift),
        outreach=engine.outreach_simulation(scored, capacity, strategy, effect),
        outreach_compare=[engine.outreach_simulation(scored, capacity, s, effect) for s in engine.STRATEGIES],
        fairness=engine.fairness_breakdown(scored, capacity, strategy),
    )


@app.get("/api/batch/download/<token>")
def batch_download(token):
    csv = RESULT_CACHE.get(token)
    if not csv:
        abort(404)
    return send_file(io.BytesIO(csv.encode()), mimetype="text/csv", as_attachment=True, download_name="scored_members.csv")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
