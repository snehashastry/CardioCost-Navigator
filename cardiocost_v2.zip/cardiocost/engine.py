"""Core logic of CardioCost Navigator (v2).

Two deliberately SEPARATE components:
  * Cardiac-risk classifier  - validated (see models/cardiac_metrics.json). Drives risk, explanations, what-ifs.
  * Insurance-cost regressor - legacy Random Forest. NOT validated (training data/target/units are not in the
    repo, ~95% of its importance is the input `annual_medical_cost`, and it saturates). It is exposed only as an
    "experimental" field, never used for segmentation or prioritisation.
Segmentation uses the member's OBSERVED prior annual cost (an input), not a model estimate.
"""
from __future__ import annotations

import json
import math
import pickle
import warnings
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
ROOT = Path(__file__).resolve().parent

CARDIAC = joblib.load(ROOT / "models" / "cardiac_model.joblib")
CARDIAC_LR = joblib.load(ROOT / "models" / "cardiac_logreg.joblib")
with open(ROOT / "models" / "insurance_cost_rf.pkl", "rb") as fh:  # trusted, repo-shipped artefact only
    INSURANCE = pickle.load(fh)
METRICS = json.load(open(ROOT / "models" / "cardiac_metrics.json"))
CARDIAC_FEATURES = METRICS["features"]
INS_FEATURES = list(INSURANCE.feature_names_in_)
THRESHOLD = float(METRICS["threshold"])
BACKGROUND = pd.read_csv(ROOT / "models" / "background_sample.csv")[CARDIAC_FEATURES]
_cfg = ROOT / "models" / "segment_config.json"
CFG = json.load(open(_cfg)) if _cfg.exists() else {"cost_split": 5300.0}
MAH = METRICS["mahalanobis"]
_INV = np.array(MAH["inv_cov"]); _MU = np.array(MAH["mean"])

DEFAULTS = dict(
    age=45, sex=1, height=170, weight=72, systolic_bp=120, diastolic_bp=80,
    cholesterol=1, gluc=1, smoker=0, alcohol=0, active=1,
    income=50000, household_size=3, dependents=1,
    hospitalizations_last_3yrs=0, days_hospitalized_last_3yrs=0, medication_count=0,
    annual_medical_cost=2000, hypertension=0, diabetes=0, asthma=0,
    cardiovascular_disease=0, cancer_history=0, kidney_disease=0,
    liver_disease=0, arthritis=0,
)
# field -> (min, max, kind). Out-of-range is REJECTED (not silently clamped) so bad data is visible.
SCHEMA = dict(
    age=(18, 100, "num"), sex=(0, 1, "cat"), height=(120, 220, "num"), weight=(30, 250, "num"),
    systolic_bp=(70, 250, "num"), diastolic_bp=(40, 150, "num"),
    cholesterol=(1, 3, "cat"), gluc=(1, 3, "cat"), smoker=(0, 1, "cat"), alcohol=(0, 1, "cat"), active=(0, 1, "cat"),
    income=(0, 5e6, "num"), household_size=(1, 20, "num"), dependents=(0, 20, "num"),
    hospitalizations_last_3yrs=(0, 100, "num"), days_hospitalized_last_3yrs=(0, 1100, "num"),
    medication_count=(0, 100, "num"), annual_medical_cost=(0, 1e6, "num"),
    **{k: (0, 1, "cat") for k in ["hypertension", "diabetes", "asthma", "cardiovascular_disease",
                                  "cancer_history", "kidney_disease", "liver_disease", "arthritis"]},
)
CORE = ["age", "sex", "height", "weight", "systolic_bp", "diastolic_bp", "cholesterol", "gluc", "smoker", "alcohol", "active"]


class ValidationError(ValueError):
    def __init__(self, errors: list[str]):
        super().__init__("; ".join(errors)); self.errors = errors


def validate(p: dict, strict_core: bool = False) -> dict:
    """Coerce + range-check one record. Raises ValidationError listing every problem."""
    if not isinstance(p, dict):
        raise ValidationError(["Input must be a JSON object."])
    out, errs = dict(DEFAULTS), []
    for k, (lo, hi, kind) in SCHEMA.items():
        v = p.get(k)
        if v is None or (isinstance(v, str) and v.strip() == "") or (isinstance(v, float) and math.isnan(v)):
            if strict_core and k in CORE:
                errs.append(f"{k}: required")
            continue
        try:
            f = float(v)
        except (TypeError, ValueError):
            errs.append(f"{k}: not a number"); continue
        if not math.isfinite(f):
            errs.append(f"{k}: not finite"); continue
        if not lo <= f <= hi:
            errs.append(f"{k}: {f:g} outside allowed range {lo:g}-{hi:g}"); continue
        if kind == "cat" and f != int(f):
            errs.append(f"{k}: must be a whole number"); continue
        out[k] = f
    if not errs and out["diastolic_bp"] >= out["systolic_bp"]:
        errs.append("diastolic_bp must be lower than systolic_bp")
    if errs:
        raise ValidationError(errs)
    out["bmi"] = round(out["weight"] / (out["height"] / 100) ** 2, 2)
    return out


clean = validate  # backwards-compatible name


def _cardiac_frame(rows: list[dict]) -> pd.DataFrame:
    return pd.DataFrame([{
        "age": r["age"], "gender": r["sex"], "height": r["height"], "weight": r["weight"],
        "ap_hi": r["systolic_bp"], "ap_lo": r["diastolic_bp"], "cholesterol": r["cholesterol"],
        "gluc": r["gluc"], "smoke": r["smoker"], "alco": r["alcohol"], "active": r["active"],
        "bmi": r["bmi"]} for r in rows])[CARDIAC_FEATURES]


def cardiac_risk(rows: list[dict]) -> np.ndarray:
    return CARDIAC.predict_proba(_cardiac_frame(rows))[:, 1]


def insurance_cost_experimental(rows: list[dict]) -> np.ndarray:
    df = pd.DataFrame([{k: r[k] for k in INS_FEATURES} for r in rows])[INS_FEATURES]
    return INSURANCE.predict(df)


def tier(risk: float) -> str:
    return "High" if risk >= 0.60 else "Moderate" if risk >= 0.35 else "Low"


def segment(risk: float, observed_cost: float, cost_split: float | None = None) -> dict:
    split = CFG["cost_split"] if cost_split is None else cost_split
    hi_r, hi_c = risk >= THRESHOLD, observed_cost >= split
    if hi_r and hi_c:
        return dict(id="critical", name="Critical - care management",
                    action="Model flags elevated cardiac risk AND prior-year cost is high: candidate for care-management review.")
    if hi_r:
        return dict(id="hidden", name="Hidden risk - prevent early",
                    action="Elevated modelled risk but prior-year cost not yet high: candidate for preventive outreach.")
    if hi_c:
        return dict(id="review", name="Cost review - check utilisation",
                    action="Lower modelled cardiac risk but high prior-year cost: review utilisation (other conditions may drive cost).")
    return dict(id="healthy", name="Healthy - routine", action="Low modelled risk and low prior-year cost: routine wellness.")


# ------------------------------------------------------------------ explainability
FEATURE_LABELS = dict(age="Age", gender="Sex", height="Height", weight="Weight", ap_hi="Systolic BP", ap_lo="Diastolic BP",
                      cholesterol="Cholesterol", gluc="Glucose", smoke="Smoking", alco="Alcohol", active="Physical activity", bmi="BMI")


def shapley(row: pd.DataFrame, n_bg: int = 40, n_perm: int = 12, seed: int = 0) -> dict:
    """Monte-Carlo permutation Shapley values on the probability scale (model-agnostic, own implementation).
    Additive by construction: base + sum(phi) == f(x) for each sampled path; estimate has sampling noise."""
    rng = np.random.default_rng(seed)
    d = len(CARDIAC_FEATURES)
    x = row[CARDIAC_FEATURES].values.astype(float)[0]
    bg = BACKGROUND.values.astype(float)
    bidx = rng.choice(len(bg), n_bg, replace=False)
    hybrids, meta = [], []
    for b in bidx:
        for _ in range(n_perm):
            perm = rng.permutation(d); cur = bg[b].copy(); hybrids.append(cur.copy())
            for j in perm:
                cur[j] = x[j]; hybrids.append(cur.copy())
            meta.append(perm)
    P = CARDIAC.predict_proba(pd.DataFrame(np.array(hybrids), columns=CARDIAC_FEATURES))[:, 1].reshape(-1, d + 1)
    phi = np.zeros(d)
    for pr, perm in zip(P, meta):
        phi[perm] += np.diff(pr)
    phi /= len(meta)
    se = np.zeros(d); diffs = np.zeros((len(meta), d))
    for i, (pr, perm) in enumerate(zip(P, meta)):
        diffs[i, perm] = np.diff(pr)
    se = diffs.std(0) / math.sqrt(len(meta))
    base = float(P[:, 0].mean())
    return dict(base=base, phi=phi, se=se)


def explain_shap(p: dict, risk: float) -> dict:
    fr = _cardiac_frame([p])
    s = shapley(fr)
    rows = [dict(feature=f, label=FEATURE_LABELS[f], value=float(fr[f].iloc[0]), shap=float(v), se=float(e))
            for f, v, e in zip(CARDIAC_FEATURES, s["phi"], s["se"])]
    rows.sort(key=lambda r: -abs(r["shap"]))
    return dict(base=s["base"], prediction=float(risk), contributions=rows,
                note="Shapley contributions on the probability scale vs. an average training patient. They describe what the "
                     "MODEL used, not what causes disease. Height, weight and BMI are correlated, so their credit is shared.")


def global_importance() -> list[dict]:
    return [dict(feature=d["feature"], label=FEATURE_LABELS[d["feature"]], auc_drop=d["mean"], std=d["std"])
            for d in METRICS["permutation_importance"]]


# ------------------------------------------------------------------ uncertainty / OOD
def uncertainty(p: dict, risk: float) -> dict:
    fr = _cardiac_frame([p]); st = METRICS["feature_stats"]; warns = []
    for f in CARDIAC_FEATURES:
        v, s = float(fr[f].iloc[0]), st[f]
        if v < s["min"] or v > s["max"]:
            warns.append(dict(level="high", msg=f"{FEATURE_LABELS[f]} = {v:g} is outside the range seen in training data ({s['min']:g}-{s['max']:g}); prediction is an extrapolation."))
        elif v < s["p01"] or v > s["p99"]:
            warns.append(dict(level="medium", msg=f"{FEATURE_LABELS[f]} = {v:g} is unusual (outside the 1st-99th percentile of training data)."))
    z = fr.values.astype(float)[0] - _MU
    md = float(np.sqrt(z @ _INV @ z))
    if md > MAH["p999"]:
        warns.append(dict(level="high", msg="Combination of values is very atypical for the training population (multivariate distance > 99.9th percentile)."))
    elif md > MAH["p99"]:
        warns.append(dict(level="medium", msg="Combination of values is atypical for the training population (multivariate distance > 99th percentile)."))
    lr = float(CARDIAC_LR.predict_proba(fr)[:, 1][0])
    if abs(lr - risk) > 0.15:
        warns.append(dict(level="medium", msg=f"Two different models disagree ({risk:.0%} vs {lr:.0%}); treat the estimate as less certain."))
    if abs(risk - THRESHOLD) < 0.05:
        warns.append(dict(level="info", msg="Risk is within 5 points of the decision threshold; classification could flip with small input changes."))
    if p["age"] < 30 or p["age"] > 65:
        warns.append(dict(level="medium", msg="Training data covers ages ~30-65; age is outside that span."))
    lvl = "high" if any(w["level"] == "high" for w in warns) else "medium" if any(w["level"] == "medium" for w in warns) else "ok"
    return dict(level=lvl, warnings=warns, second_model_risk=lr, mahalanobis=md)


# ------------------------------------------------------------------ what-if (model-based scenarios, NOT treatment effects)
def _healthy(p: dict, factor: str) -> dict:
    q = dict(p)
    if factor == "Blood pressure":
        q["systolic_bp"], q["diastolic_bp"] = 120, 80
    elif factor == "Body weight (BMI)":
        q["weight"] = 22.5 * (q["height"] / 100) ** 2; q["bmi"] = 22.5
    elif factor == "Cholesterol":
        q["cholesterol"] = 1
    elif factor == "Glucose":
        q["gluc"] = 1
    elif factor == "Smoking":
        q["smoker"] = 0
    elif factor == "Alcohol":
        q["alcohol"] = 0
    elif factor == "Physical inactivity":
        q["active"] = 1
    elif factor == "Age":
        q["age"] = 35
    return q


FACTORS = ["Blood pressure", "Body weight (BMI)", "Cholesterol", "Glucose", "Smoking", "Alcohol", "Physical inactivity", "Age"]
MODIFIABLE = set(FACTORS) - {"Age"}


def counterfactual_drivers(p: dict, base_risk: float) -> list[dict]:
    risks = cardiac_risk([_healthy(p, f) for f in FACTORS])
    out = [dict(factor=f, delta=float(base_risk - r), modifiable=f in MODIFIABLE) for f, r in zip(FACTORS, risks)]
    return sorted(out, key=lambda d: -d["delta"])


def _bmi(q):
    q["bmi"] = round(q["weight"] / (q["height"] / 100) ** 2, 2); return q


SCENARIOS = {
    "quit_smoking": ("Quit smoking", lambda p: {**p, "smoker": 0}),
    "bp_control": ("Bring BP to 120/80", lambda p: {**p, "systolic_bp": min(p["systolic_bp"], 120), "diastolic_bp": min(p["diastolic_bp"], 80)}),
    "healthy_bmi": ("Reach BMI 24", lambda p: _bmi({**p, "weight": min(p["weight"], 24 * (p["height"] / 100) ** 2)})),
    "exercise": ("Become physically active", lambda p: {**p, "active": 1}),
    "cholesterol": ("Normal cholesterol", lambda p: {**p, "cholesterol": 1}),
}
WHATIF_CAVEAT = ("Model-based scenario: shows how this model's score changes if inputs changed. It is an association learned from "
                 "population data, NOT evidence that the intervention would produce that reduction in this person.")


def whatif(p: dict, chosen: list[str]) -> dict:
    base = float(cardiac_risk([p])[0])
    singles = []
    for key, (label, fn) in SCENARIOS.items():
        r = float(cardiac_risk([fn(p)])[0])
        singles.append(dict(id=key, label=label, risk=r, reduction=base - r))
    q = dict(p)
    for k in chosen:
        if k in SCENARIOS:
            q = _bmi(SCENARIOS[k][1](q))
    combined = float(cardiac_risk([q])[0])
    return dict(base=base, combined=combined, singles=sorted(singles, key=lambda d: -d["reduction"]), caveat=WHATIF_CAVEAT)


def percentile_of(risk: float) -> int:
    return int(np.searchsorted(METRICS["risk_percentiles"], risk))


# ------------------------------------------------------------------ experimental insurance output
def insurance_block(p: dict) -> dict:
    est = float(insurance_cost_experimental([p])[0])
    reasons = ["Training data, target definition and currency/unit of this model are not documented in the repository.",
               "~95% of its learned signal is the input 'annual_medical_cost'; clinical inputs barely change it."]
    if p["annual_medical_cost"] > 20000:
        reasons.append("Input annual cost is above the range where the model's output stops responding (it saturates near ~4,900).")
    return dict(status="experimental-unvalidated", estimate=round(est, 0), unit="unknown (legacy model; unit not documented)",
                reliable=False, reasons=reasons)


def assess(payload: dict) -> dict:
    p = validate(payload, strict_core=True)
    risk = float(cardiac_risk([p])[0])
    seg = segment(risk, p["annual_medical_cost"])
    scen = whatif(p, [])
    flags = []
    if p["systolic_bp"] >= 140 or p["diastolic_bp"] >= 90:
        flags.append("Blood pressure in hypertensive range")
    if p["bmi"] >= 30:
        flags.append("BMI in obese range")
    if p["smoker"]:
        flags.append("Current smoker")
    if p["cholesterol"] >= 2 or p["gluc"] >= 2:
        flags.append("Elevated cholesterol or glucose")
    return dict(
        inputs=p, risk=risk, tier=tier(risk), flagged=bool(risk >= THRESHOLD), threshold=THRESHOLD,
        population_percentile=percentile_of(risk), segment=seg, segment_basis="observed prior-year cost (input) vs cohort cost split",
        shap=explain_shap(p, risk), drivers=counterfactual_drivers(p, risk), uncertainty=uncertainty(p, risk),
        recommended=[s for s in scen["singles"] if s["reduction"] > 0.005][:3], flags=flags, bmi=p["bmi"],
        insurance_experimental=insurance_block(p),
        disclaimer="Population-level screening signal from a public dataset. Not a diagnosis; not clinically validated.",
    )


# ------------------------------------------------------------------ drift (PSI vs training distribution)
def psi_report(df_core: pd.DataFrame) -> list[dict]:
    """df_core has CARDIAC_FEATURES columns. PSI<0.1 stable, 0.1-0.25 moderate, >0.25 significant shift."""
    out = []
    for f in CARDIAC_FEATURES:
        e = np.array(METRICS["psi_bins"][f]["edges"]); exp = np.array(METRICS["psi_bins"][f]["share"])
        act = np.histogram(np.clip(df_core[f].astype(float), e[0], e[-1]), bins=e)[0] / max(len(df_core), 1)
        exp, act = np.clip(exp, 1e-4, None), np.clip(act, 1e-4, None)
        v = float(np.sum((act - exp) * np.log(act / exp)))
        out.append(dict(feature=f, label=FEATURE_LABELS[f], psi=v, status="significant" if v > .25 else "moderate" if v > .1 else "stable"))
    return sorted(out, key=lambda d: -d["psi"])


# ------------------------------------------------------------------ outreach / resource simulation
STRATEGIES = {"risk": "Highest modelled risk first", "hidden": "Hidden-risk first (high risk, lower cost)",
              "risk_cost": "Risk x observed prior cost"}


def outreach_simulation(scored: pd.DataFrame, capacity: int, strategy: str, effect: float) -> dict:
    """What-if allocation of limited outreach slots. `effect` = ASSUMED relative risk reduction (0-1) among those
    reached - a user-set planning assumption, not an estimate from evidence."""
    if strategy not in STRATEGIES:
        raise ValueError("unknown strategy")
    s = scored.copy()
    key = {"risk": s["cardiac_risk"], "hidden": s["cardiac_risk"] * (s["observed_cost"] < CFG["cost_split"]) + 0.001 * s["cardiac_risk"],
           "risk_cost": s["cardiac_risk"] * s["observed_cost"]}[strategy]
    capacity = int(max(0, min(capacity, len(s))))
    pick = s.loc[key.sort_values(ascending=False).index[:capacity]]
    total = float(s["cardiac_risk"].sum())
    return dict(strategy=strategy, strategy_label=STRATEGIES[strategy], capacity=capacity, assumed_effect=effect,
                reached=capacity, mean_risk_reached=float(pick["cardiac_risk"].mean()) if capacity else 0.0,
                share_of_flagged_reached=float(pick["flagged"].mean()) if capacity else 0.0,
                expected_cases_in_reached=float(pick["cardiac_risk"].sum()),
                hypothetical_cases_averted=float(pick["cardiac_risk"].sum() * effect),
                cohort_expected_cases=total,
                caveat="HYPOTHETICAL. 'Cases averted' = sum of modelled risk among reached members x an assumed effect size you set. "
                       "Risk is prevalence of existing disease in the training data, not future events. No savings or outcomes are claimed.")


def fairness_breakdown(scored: pd.DataFrame, capacity: int, strategy: str) -> list[dict]:
    """Who gets the outreach slots? Compares group shares in cohort vs in the selected set."""
    s = scored.copy()
    key = {"risk": s["cardiac_risk"], "hidden": s["cardiac_risk"] * (s["observed_cost"] < CFG["cost_split"]) + 0.001 * s["cardiac_risk"],
           "risk_cost": s["cardiac_risk"] * s["observed_cost"]}[strategy]
    pick = s.loc[key.sort_values(ascending=False).index[:int(capacity)]]
    out = []
    for gname, col in [("Sex", s["sex"].map({0: "Female", 1: "Male"})),
                       ("Age band", pd.cut(s["age"], [0, 45, 55, 65, 200], labels=["<45", "45-54", "55-64", "65+"]))]:
        for lvl in pd.Series(col).dropna().unique():
            m = (col == lvl)
            out.append(dict(group=gname, level=str(lvl), n=int(m.sum()), cohort_share=float(m.mean()),
                            selected_share=float((col.loc[pick.index] == lvl).mean()) if len(pick) else 0.0,
                            mean_risk=float(s.loc[m, "cardiac_risk"].mean()), flagged_share=float(s.loc[m, "flagged"].mean())))
    return out
